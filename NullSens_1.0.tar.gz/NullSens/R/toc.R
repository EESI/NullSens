toc <-
function()
{
   type <- get(".type", envir=baseenv())
   toc <- proc.time()[type]
   tic <- get(".tic", envir=baseenv())
   #print(toc - tic)
   invisible(toc)
   return(toc-tic)
}
